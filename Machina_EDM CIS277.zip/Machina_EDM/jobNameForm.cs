﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Machina_EDM
{
    public partial class jobNameForm : Form
    {
        public jobNameForm()
        {
            InitializeComponent();
        }

        private void fe_OK_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void fe_Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
