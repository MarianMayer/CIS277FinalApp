﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Machina_EDM
{
    public partial class Form_main : Form
    {
// Custom functions
        //==========================VARIABLES
        myWorkFlow.mitsubishiEDMprogramCollomn[] PLine;
        public void initializeMainForm()
        {
            PLine=new myWorkFlow.mitsubishiEDMprogramCollomn[1];
            //NUMBERS OF LINES SET HERE
            int linesCount = 24;
            for (int i = 0; i < linesCount-1; i++)
            {
                dataGridView1.Rows.Add();
            }
            for (int i = 0; i < linesCount; i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = i;
            }
            //column 0
            string[] column0 = { "W:", "Start X", "Y", "Z", "C", "Depth Z", "X", "Y", "C", "Steichen No:", "Orb Ptn D", "M CODE M", "1st ELEC.T", "UNDERSIZ.R", "2st ELEC.T", "UNDERSIZ.R", "3rd ELEC.T", "UNDERSIZ.R", "4th ELEC.T", "UNDERSIZ.R", "5th ELEC.T", "UNDERSIZ.R", "6th ELEC.T", "UNDERSIZ.R" };
            dataGridView1.Columns[0].ValueType = typeof(string);
            for (int i = 0; i < linesCount; i++)
            {
                dataGridView1.Rows[i].Cells[0].Value = column0[i];
            }
            //column 1
            dataGridView1.Rows[11].Cells[1].ValueType = typeof(string) ;
            dataGridView1.Rows[11].Cells[1].Value = "M55(100)";
            string[] column2 = { "1", "0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0"};
            
            //dataGridView1.Columns[2].DefaultCellStyle.Format = "0.00000##";
            dataGridView1.Columns[2].ValueType = typeof(decimal);
            for (int i = 0; i < linesCount; i++)
            {
                dataGridView1.Rows[i].Cells[2].Value = column2[i];
            }

        }
        //
        public Form_main()
        {
            InitializeComponent();
        }
        //
        private void fe_jobName_Click(object sender, EventArgs e)
        {
            jobNameForm fJobName= new jobNameForm();
            fJobName.Show();
        }
        //
        private void Form_main_Load(object sender, EventArgs e)
        {
          initializeMainForm();
        }
        //
        private void fe_LoadTemplate_Click(object sender, EventArgs e)
        {
            string templateFileName = "";
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.InitialDirectory = @"\\3R-WM114\3RNCLibrary-114\STEICHEN_E-PACKS";
            openFileDialog1.Filter = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((templateFileName = openFileDialog1.FileName) != null)
                    {
                        fe_Template.LoadFile(templateFileName,RichTextBoxStreamType.PlainText);                       
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
            PLine[0] = new myWorkFlow.mitsubishiEDMprogramCollomn(fe_Template.Lines[5]);
        }
        //
        private void extractFromTemplate_Click(object sender, EventArgs e)
        {
            string[] templateContentIn = fe_Template.Text.Split(Environment.NewLine.ToCharArray());
            string line = templateContentIn[4];
            if (line.StartsWith("M55(100)"))
            { dataGridView1.Rows[11].Cells[1].Value = "M55(100)"; }
           line=templateContentIn[5];
        }
               //========PREVIEW BUTTON ===================
        private void preview_Click(object sender, EventArgs e)
        {
            if (fe_Template.Lines.Count( ) >0)
            {   PLine[0].sX= Convert.ToDecimal(dataGridView1.Rows[1].Cells[2].Value);
                PLine[0].sY = Convert.ToDecimal(dataGridView1.Rows[2].Cells[2].Value);
                PLine[0].sZ = Convert.ToDecimal(dataGridView1.Rows[3].Cells[2].Value);
                PLine[0].sC = Convert.ToDecimal(dataGridView1.Rows[4].Cells[2].Value);
                PLine[0].dZ = Convert.ToDecimal(dataGridView1.Rows[5].Cells[2].Value);

                string tempLine = Convert.ToString( dataGridView1.Rows[11].Cells[1].Value);
                if (tempLine.StartsWith("M55(") & tempLine.EndsWith(")") )
                {
                    string tempInt = tempLine.Substring(4, tempLine.Length - 5);
                    PLine[0].tankHeight = Convert.ToInt32(tempInt);
                }
                else
                {
                    MessageBox.Show("Tank Height field is messed up! \n Tank Height will fall to default 100.");
                    PLine[0].tankHeight = 100;
                }
                PLine[0].generateNewLines();
                // GENERATE TANK HEIGHT LINE
                int selectStart = fe_Template.GetFirstCharIndexFromLine(4);
                int selectLength = PLine[0].tankHeight < 100 ? 4 : 5;
                fe_Template.Select(selectStart, fe_Template.Lines[4].Length);
                fe_Template.SelectionColor = Color.Blue;
                fe_Template.SelectedText = PLine[0].TankHeightLineOut;
                fe_Template.Select(selectStart +3, selectLength);
                fe_Template.SelectionColor = Color.Red;
                
                selectStart = fe_Template.GetFirstCharIndexFromLine(5);
                //int s2 = 5 < fe_Template.Lines.Count() - 1 ?
                //          fe_Template.GetFirstCharIndexFromLine(5 + 1) - 1 :
                //          fe_Template.Text.Length;
                fe_Template.Select(selectStart, fe_Template.Lines[5].Length);
                fe_Template.SelectionColor = Color.Blue;
                fe_Template.SelectedText = PLine[0].CoordinatesLineOut + PLine[0].originalCoordinatesLine.Substring(40);

                fe_Template.Select(selectStart, PLine[0].CoordinatesLineOut.Length);
                fe_Template.SelectionColor = Color.Red;
            }
            else
            { MessageBox.Show("Please select a Process first!"); }
        }
        //
        private void dataGridView1_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex == 2 & e.ColumnIndex == 2)
            {
                try
                {
                   // decimal
                   // dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value
                }
                catch
                {
                }
                
            }
        }
        //
        private void SaveAs_Click_1(object sender, EventArgs e)
        {
            string saveAsFileName = "";
            SaveFileDialog openFileDialog1 = new SaveFileDialog();
            //openFileDialog1.InitialDirectory = @"\\3R-WM114\3RNCLibrary-114\Mitsubishi\ECI_Machinist";
            openFileDialog1.Filter = "PRO files (*.pro)|*.pro|txt files (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 1;
            openFileDialog1.RestoreDirectory = true;
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if ((saveAsFileName = openFileDialog1.FileName) != null)
                    {
                        fe_Template.SaveFile(saveAsFileName, RichTextBoxStreamType.PlainText);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: Could SAVE file TO disk. Original error: " + ex.Message);
                }
            }
        }

        private void dataGridView1_CellValidating(object sender, DataGridViewCellValidatingEventArgs e)
        {            
            //string columnName = dataGridView1.Columns[e.ColumnIndex].HeaderText;
            // Abort custom validation function (allows the change witout checking) if the column namd is"7".
                    //if (columnName.Equals("7")) return;
            // Confirm that the cell is not empty.
            //if (string.IsNullOrEmpty(e.FormattedValue.ToString()))
            //{ 
            //    dataGridView1.Rows[e.RowIndex].ErrorText = "field can not be empty";
            //    MessageBox.Show("Field can not be emtpty!");
            //    e.Cancel = true;
            //}
            //else
            //    if (e.ColumnIndex==2 & e.RowIndex >=1 & e.RowIndex <=5)
            //    {int tempInt;
            // if (int.TryParse(dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex], tempInt))
            //     decimal.TryParse();
            //     }
            //   MessageBox.Show("end validation");
        }
        //
    }
}
