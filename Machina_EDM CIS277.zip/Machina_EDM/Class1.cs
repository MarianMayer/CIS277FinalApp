﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace myWorkFlow
{
    public class myJobClass
    {
        //VARIABLES
        public string
            jobNumber = "0000",
            jobRevision = "",
            jobT = "00",
            jobDet = "000",
            jobDescription = "",
            jobInfo = "",
            jobDate = "";
        //CONSTRUCTOR=======
        public myJobClass()
        {
            //NOTHING IN THE CONSTRUCTOR YET
        }
        public string readFileName(string arg1)
        {
            jobNumber = "-";
            jobRevision = "-";
            jobT = "-";
            jobDet = "-";
            jobDescription = "-";
            jobInfo = "-";
            jobDate = "-";
            string result = "Still OK";
            char[] delimiterChars = { ' ', '_'};

            string[] words = arg1.ToUpper().Split(delimiterChars);
            
            // reading job number========================================
            try
            {
                if (words.Count() > 1)
                {//at least two words
                    if ((words[0].Count() >= 4))
                    {//first word at least 4 characters
                        if (char.IsDigit(words[0][0]) & char.IsDigit(words[0][1]) & char.IsDigit(words[0][2]) & char.IsDigit(words[0][3]))
                        {//first 4 char are digits
                            jobNumber = words[0].Substring(0, 4);
                            if (words[0].Length>4)
                            {//there is a revision number
                                if ((words[0][4]=='-') & (words[0].Length>5))
                                {//there is a valid revision
                                    if (words[0][4]=='-')
                                    {//i have '-'
                                        jobRevision=words[0].Substring(6);
                                    }
                                    else
                                    {//i don't have '-'
                                        jobRevision=words[0].Substring(5);
                                    }
                                }
                                else { result = "!Error:Revision wrong format ( no -)"; }
                            }else {jobRevision="";}//no revision number
                        }else { result = "!Error:job number is not a number"; }
                    }else { result = "!Error:not enough digits in the job number"; }
                }else { result = "!Error:not enough words in the full string"; }
            }
            catch
            {
                result = "Reading job number Try Catch !Error";
            }
            return result;
        }
        
    public class myMitsEDM
    {
        //VARIABLES
        public decimal sX,sY,sZ,sC,dZ;
        public string orbitNumber;
        public decimal eReduction;
    }
}
    //===================================================
    //===================================================
    public class myCSVFile
    {
        public string csvFileName = "N/A ,";
        public string csvHeaderLine = "N/A ,";
        public string csvLine = "N/A ,";
        // Constructor====
        public myCSVFile(string arg1)
        {
            csvFileName = arg1;
            csvHeaderLine = "N/A ,";
            csvLine = "N/A ,";
        }
        public void writeFile()
        {
            if (!System.IO.File.Exists(csvFileName))
            {
                System.IO.File.WriteAllText (csvFileName, csvHeaderLine+ Environment.NewLine);
                csvHeaderLine = "N/A ,";
            }
            System.IO.File.AppendAllText(csvFileName, csvLine + Environment.NewLine);
            csvLine = "N/A ,";
        }
    }
    //===================================================
    //===================================================
    public class mitsubishiEDMprogramCollomn
    {
        public decimal sX, sY, sZ, sC, dX, dY, dZ, dC;
        public decimal reduction;
        public int tankHeight;
        public string  originalCoordinatesLine;
        public string  CoordinatesLineOut, TankHeightLineOut;
        public mitsubishiEDMprogramCollomn(string constructorLine)
        {   originalCoordinatesLine = constructorLine;
            sX = sY = sZ = sC = dX = dY = dZ = dC = 100.0m;
            tankHeight = 100;
            //resultString = Regex.Match(subjectString, @"\d+").Value;
        }
        public void generateNewLines()
        {
            //W1SX0.0000SY0.0000SZ0.0000SC0.000Z0.0000E8001D300T101,102,103,104R0.0050,0.0050,0.0050,0.0050
            CoordinatesLineOut = "W1";
            CoordinatesLineOut += "SX" + sX.ToString("F5");
            CoordinatesLineOut += "SY" + sY.ToString("F5");
            CoordinatesLineOut += "SZ" + sZ.ToString("F5");
            CoordinatesLineOut += "SC" + sC.ToString("F5");
            CoordinatesLineOut += "Z" + dZ.ToString("F5");
            //==============================
            //M55(100)P111,111,111,111PB222,222,222,222
            TankHeightLineOut = "M55(" + Convert.ToString(tankHeight) + ")P111,111,111,111PB222,222,222,222";
        }
    }
}
