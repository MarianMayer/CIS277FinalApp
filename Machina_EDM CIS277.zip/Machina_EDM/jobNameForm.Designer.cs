﻿namespace Machina_EDM
{
    partial class jobNameForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fe_NoOfSequences = new System.Windows.Forms.NumericUpDown();
            this.fe_quantity = new System.Windows.Forms.NumericUpDown();
            this.fe_drawingNo = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Verify_button = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.fe_jobDetNumber = new System.Windows.Forms.NumericUpDown();
            this.fe_jobDescription = new System.Windows.Forms.TextBox();
            this.fe_jobTNumber = new System.Windows.Forms.NumericUpDown();
            this.fe_jobRevision = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.fe_DueDate = new System.Windows.Forms.DateTimePicker();
            this.fe_Description = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.fe_CustomerName = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.fe_jobNumber = new System.Windows.Forms.NumericUpDown();
            this.fe_OK = new System.Windows.Forms.Button();
            this.fe_Cancel = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fe_NoOfSequences)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_quantity)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_drawingNo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_jobDetNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_jobTNumber)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_jobNumber)).BeginInit();
            this.SuspendLayout();
            // 
            // fe_NoOfSequences
            // 
            this.fe_NoOfSequences.Increment = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.fe_NoOfSequences.Location = new System.Drawing.Point(123, 158);
            this.fe_NoOfSequences.Maximum = new decimal(new int[] {
            24,
            0,
            0,
            0});
            this.fe_NoOfSequences.Minimum = new decimal(new int[] {
            3,
            0,
            0,
            0});
            this.fe_NoOfSequences.Name = "fe_NoOfSequences";
            this.fe_NoOfSequences.Size = new System.Drawing.Size(120, 20);
            this.fe_NoOfSequences.TabIndex = 34;
            this.fe_NoOfSequences.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // fe_quantity
            // 
            this.fe_quantity.Location = new System.Drawing.Point(123, 131);
            this.fe_quantity.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.fe_quantity.Name = "fe_quantity";
            this.fe_quantity.Size = new System.Drawing.Size(63, 20);
            this.fe_quantity.TabIndex = 33;
            // 
            // fe_drawingNo
            // 
            this.fe_drawingNo.Location = new System.Drawing.Point(123, 104);
            this.fe_drawingNo.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.fe_drawingNo.Name = "fe_drawingNo";
            this.fe_drawingNo.Size = new System.Drawing.Size(120, 20);
            this.fe_drawingNo.TabIndex = 32;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(20, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 13);
            this.label8.TabIndex = 44;
            this.label8.Text = "No. of Operations:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(67, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(49, 13);
            this.label7.TabIndex = 43;
            this.label7.Text = "Quantity:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(47, 104);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(69, 13);
            this.label6.TabIndex = 42;
            this.label6.Text = "Drawing No.:";
            // 
            // Verify_button
            // 
            this.Verify_button.Location = new System.Drawing.Point(425, 48);
            this.Verify_button.Name = "Verify_button";
            this.Verify_button.Size = new System.Drawing.Size(75, 23);
            this.Verify_button.TabIndex = 30;
            this.Verify_button.Text = "Verify Name";
            this.Verify_button.UseVisualStyleBackColor = true;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(404, 26);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 41;
            this.label5.Text = "_";
            // 
            // fe_jobDetNumber
            // 
            this.fe_jobDetNumber.Location = new System.Drawing.Point(334, 21);
            this.fe_jobDetNumber.Maximum = new decimal(new int[] {
            900,
            0,
            0,
            0});
            this.fe_jobDetNumber.Name = "fe_jobDetNumber";
            this.fe_jobDetNumber.Size = new System.Drawing.Size(64, 20);
            this.fe_jobDetNumber.TabIndex = 27;
            this.fe_jobDetNumber.Value = new decimal(new int[] {
            200,
            0,
            0,
            0});
            // 
            // fe_jobDescription
            // 
            this.fe_jobDescription.Location = new System.Drawing.Point(423, 21);
            this.fe_jobDescription.Name = "fe_jobDescription";
            this.fe_jobDescription.Size = new System.Drawing.Size(155, 20);
            this.fe_jobDescription.TabIndex = 29;
            // 
            // fe_jobTNumber
            // 
            this.fe_jobTNumber.Location = new System.Drawing.Point(249, 22);
            this.fe_jobTNumber.Maximum = new decimal(new int[] {
            99,
            0,
            0,
            0});
            this.fe_jobTNumber.Name = "fe_jobTNumber";
            this.fe_jobTNumber.Size = new System.Drawing.Size(35, 20);
            this.fe_jobTNumber.TabIndex = 25;
            // 
            // fe_jobRevision
            // 
            this.fe_jobRevision.Location = new System.Drawing.Point(187, 21);
            this.fe_jobRevision.Name = "fe_jobRevision";
            this.fe_jobRevision.Size = new System.Drawing.Size(28, 20);
            this.fe_jobRevision.TabIndex = 24;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(290, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(38, 13);
            this.label4.TabIndex = 38;
            this.label4.Text = "_DET:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(223, 24);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(20, 13);
            this.label3.TabIndex = 37;
            this.label3.Text = "_T";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(171, 22);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(10, 13);
            this.label2.TabIndex = 35;
            this.label2.Text = "-";
            // 
            // fe_DueDate
            // 
            this.fe_DueDate.Location = new System.Drawing.Point(407, 157);
            this.fe_DueDate.Name = "fe_DueDate";
            this.fe_DueDate.Size = new System.Drawing.Size(200, 20);
            this.fe_DueDate.TabIndex = 40;
            this.fe_DueDate.Value = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            // 
            // fe_Description
            // 
            this.fe_Description.Location = new System.Drawing.Point(407, 130);
            this.fe_Description.Name = "fe_Description";
            this.fe_Description.Size = new System.Drawing.Size(100, 20);
            this.fe_Description.TabIndex = 39;
            this.fe_Description.Text = "N/A";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(349, 157);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(56, 13);
            this.label14.TabIndex = 31;
            this.label14.Text = "Due Date:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(342, 130);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(63, 13);
            this.label13.TabIndex = 28;
            this.label13.Text = "Description:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(351, 103);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 26;
            this.label12.Text = "Customer:";
            // 
            // fe_CustomerName
            // 
            this.fe_CustomerName.Location = new System.Drawing.Point(407, 103);
            this.fe_CustomerName.Name = "fe_CustomerName";
            this.fe_CustomerName.Size = new System.Drawing.Size(100, 20);
            this.fe_CustomerName.TabIndex = 36;
            this.fe_CustomerName.Text = "N/A";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(41, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 13);
            this.label1.TabIndex = 23;
            this.label1.Text = "JOB Number:";
            // 
            // fe_jobNumber
            // 
            this.fe_jobNumber.Location = new System.Drawing.Point(113, 22);
            this.fe_jobNumber.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
            this.fe_jobNumber.Minimum = new decimal(new int[] {
            3000,
            0,
            0,
            0});
            this.fe_jobNumber.Name = "fe_jobNumber";
            this.fe_jobNumber.Size = new System.Drawing.Size(48, 20);
            this.fe_jobNumber.TabIndex = 22;
            this.fe_jobNumber.Value = new decimal(new int[] {
            4500,
            0,
            0,
            0});
            // 
            // fe_OK
            // 
            this.fe_OK.Location = new System.Drawing.Point(407, 197);
            this.fe_OK.Name = "fe_OK";
            this.fe_OK.Size = new System.Drawing.Size(75, 23);
            this.fe_OK.TabIndex = 45;
            this.fe_OK.Text = "OK";
            this.fe_OK.UseVisualStyleBackColor = true;
            this.fe_OK.Click += new System.EventHandler(this.fe_OK_Click);
            // 
            // fe_Cancel
            // 
            this.fe_Cancel.Location = new System.Drawing.Point(524, 196);
            this.fe_Cancel.Name = "fe_Cancel";
            this.fe_Cancel.Size = new System.Drawing.Size(75, 23);
            this.fe_Cancel.TabIndex = 46;
            this.fe_Cancel.Text = "Cancel";
            this.fe_Cancel.UseVisualStyleBackColor = true;
            this.fe_Cancel.Click += new System.EventHandler(this.fe_Cancel_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(649, 232);
            this.Controls.Add(this.fe_Cancel);
            this.Controls.Add(this.fe_OK);
            this.Controls.Add(this.fe_NoOfSequences);
            this.Controls.Add(this.fe_quantity);
            this.Controls.Add(this.fe_drawingNo);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.Verify_button);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.fe_jobDetNumber);
            this.Controls.Add(this.fe_jobDescription);
            this.Controls.Add(this.fe_jobTNumber);
            this.Controls.Add(this.fe_jobRevision);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.fe_DueDate);
            this.Controls.Add(this.fe_Description);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.fe_CustomerName);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.fe_jobNumber);
            this.Name = "Form2";
            this.Text = "Form2";
            ((System.ComponentModel.ISupportInitialize)(this.fe_NoOfSequences)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_quantity)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_drawingNo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_jobDetNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_jobTNumber)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fe_jobNumber)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown fe_NoOfSequences;
        private System.Windows.Forms.NumericUpDown fe_quantity;
        private System.Windows.Forms.NumericUpDown fe_drawingNo;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button Verify_button;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown fe_jobDetNumber;
        private System.Windows.Forms.TextBox fe_jobDescription;
        private System.Windows.Forms.NumericUpDown fe_jobTNumber;
        private System.Windows.Forms.TextBox fe_jobRevision;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DateTimePicker fe_DueDate;
        private System.Windows.Forms.TextBox fe_Description;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox fe_CustomerName;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown fe_jobNumber;
        private System.Windows.Forms.Button fe_OK;
        private System.Windows.Forms.Button fe_Cancel;
    }
}